<?php

namespace App\Http\Controllers;

use Backpack\PageManager\app\Models\Page;
use App\Http\Controllers\Controller;
use Backpack\NewsCRUD\app\Models\Article;
use Backpack\MenuCRUD\app\Models\MenuItem;

class PageController extends Controller
{

    // Home
    public function home()
    {
        $this->data['menu_items'] = MenuItem::getTree();
        return view('welcome', $this->data);
    }

    // Page
    public function index($slug)
    {
        $page = Page::findBySlug($slug);

        if (!$page)
        {
            abort(404, 'Please go back to our <a href="'.url('').'">homepage</a>.');
        }

        $this->data['title'] = $page->title;
        $this->data['page'] = $page->withFakes();
        $this->data['menu_items'] = MenuItem::getTree();

        return view('pages.'.$page->template, $this->data);
    }
   
    // Articulo
    public function articulo($slug)
    {
        $page= Article::findBySlug($slug);

        if (!$page)
        {
            abort(404, 'Pleasee go back to our <a href="'.url('').'">homepage</a>.');
        }

        $this->data['title'] = $page->title;
        $this->data['page'] = $page->withFakes();
        $this->data['menu_items'] = MenuItem::getTree();

        return view('articulo', $this->data);
    }

}