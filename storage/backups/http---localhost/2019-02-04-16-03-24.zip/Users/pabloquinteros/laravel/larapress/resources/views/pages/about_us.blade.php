Template About <br>
{!! $page->content !!}
