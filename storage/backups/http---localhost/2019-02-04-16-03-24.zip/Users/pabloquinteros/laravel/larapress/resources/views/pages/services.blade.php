Template Services <br>
{!! $page->content !!}